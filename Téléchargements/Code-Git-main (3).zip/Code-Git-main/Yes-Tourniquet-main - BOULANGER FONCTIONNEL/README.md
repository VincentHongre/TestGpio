# Utilisation du projet

## Prérequis

Installer Node.JS

## Back

- Ouvrir un terminal
- Exécuter la commande `cd back` pour se situer dans la partie back
- Exécuter la commande `npm i`
- Brancher le prototype au PC puis exécuter la commande `node ws.js LE_PORT_DU_PROTOTYPE`

## Front

- Ouvrir un 2ème terminal
- Exécuter la commande `cd front` pour se situer dans la partie front
- Exécuter la commande `npm run i`
- Puis éxécuter la `npm run start`
- Une page web va alors s'ouvrir à l'adresse `http://localhost:3000/`
